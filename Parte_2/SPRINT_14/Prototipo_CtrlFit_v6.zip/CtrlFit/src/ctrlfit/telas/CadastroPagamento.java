package ctrlfit.telas;

import ctrlfit.entity.Pagamento;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CadastroPagamento extends javax.swing.JFrame {

    GerenciamentoPagamentos gerenciamentoPagamento;
    private GerenciamentoAlunos gerenciamentoAlunos; // Adicione uma variável para GerenciamentoAlunos
    private int matriculaAluno;
    private String nomeAluno;
    private int codigoAtual;
    Pagamento pagamento;

    /*
    public CadastroPagamento(GerenciamentoPagamentos teste, int matricula, String nome) {
        initComponents();
        this.gerenciamentoPagamento = teste;
        this.matriculaAluno = matricula;
        this.nomeAluno = nome;

        // Exibir a matrícula e o nome nos componentes visuais
        txtMatriculaAluno.setText(String.valueOf(matriculaAluno));
        txtNomeAluno.setText(nomeAluno);

        //data pagamento - data atual
        txtDtPagamento.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    }
     */
    //construtor para cadastro de pagamento a partir do cadastro do aluno
    public CadastroPagamento(GerenciamentoPagamentos gerenciamentoPagamento, GerenciamentoAlunos gerenciamentoAlunos, int matricula, String nome) {
        initComponents();
        this.gerenciamentoPagamento = gerenciamentoPagamento;
        this.gerenciamentoAlunos = gerenciamentoAlunos; // Inicialize a instância de GerenciamentoAlunos
        this.matriculaAluno = matricula;
        this.nomeAluno = nome;

        // Configurações visuais
        txtMatriculaAluno.setText(String.valueOf(matriculaAluno));
        txtNomeAluno.setText(nomeAluno);
        txtDtPagamento.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));

        carregarComboBox();
    }

    public void registrarPagamento() {
        try {
            //estabelecer a conexão com o banco de dados
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "UPDATE pagamento SET Aluno_Matricula_Aluno = ?, NomeAluno_Pagamento = ?, Plano_Pagamento = ?,"
                    + " Preco_Pagamento = ?, Forma_Pagamento = ?, Dt_Pagamento = ?,"
                    + " DtInicio_Aluno = ?, DtFim_Aluno = ?, Situacao_Aluno = ? WHERE Aluno_Matricula_Aluno = ?";

            // Preparar a instrução SQL
            PreparedStatement st = conexao.prepareStatement(sql);

            // Definir os valores dos parâmetros
            st.setInt(1, pagamento.getMatricula());
            st.setString(2, pagamento.getNome());
            st.setString(3, pagamento.getPlano());
            st.setDouble(4, pagamento.getPreco());
            st.setString(5, pagamento.getForma());

            //st.setDate(6, (Date) pagamento.getDtPagamento());
            //------------------------------------------------------------------
            //pagamento.getDtPagamento() retorna um java.util.Date
            Date dataUtil = pagamento.getDtPagamento();

            if (dataUtil != null) {
                java.sql.Date dataSql = new java.sql.Date(dataUtil.getTime());
                st.setDate(6, dataSql);
            } else {
                st.setNull(6, java.sql.Types.DATE);
            }
            //------------------------------------------------------------------

            //st.setDate(7, (Date) pagamento.getDtInicio());
            dataUtil = pagamento.getDtInicio();

            if (dataUtil != null) {
                java.sql.Date dataSql = new java.sql.Date(dataUtil.getTime());
                st.setDate(7, dataSql);
            } else {
                st.setNull(7, java.sql.Types.DATE);
            }

            //st.setDate(8, (Date) pagamento.getDtFim());
            dataUtil = pagamento.getDtFim();

            if (dataUtil != null) {
                java.sql.Date dataSql = new java.sql.Date(dataUtil.getTime());
                st.setDate(8, dataSql);
            } else {
                st.setNull(8, java.sql.Types.DATE);
            }

            st.setString(9, pagamento.getSituacao());
            st.setInt(10, pagamento.getMatricula());

            // Executar o UPDATE
            st.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro realizado com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public void trazerDados(int codigo) {
        this.codigoAtual = codigo;

    }

    ArrayList<Double> precoArray = new ArrayList<Double>();
    ArrayList<Integer> duracaoArray = new ArrayList<Integer>();
    //int contadorComboBox = 0;

    public void carregarComboBox() {
        try {
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "SELECT * FROM mensalidade_plano";

            PreparedStatement pstm = conexao.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();

            // Iterar pelos resultados
            while (rs.next()) {
                int codigo = rs.getInt("CodigoMensalidade_Plano");
                String nomePlano = rs.getString("NomeMensalidade_Plano");
                double precoPlano = rs.getDouble("PrecoMensalidade_Plano");
                int duracao = rs.getInt("DuracaoMensalidade_Plano");
                String descricao = rs.getString("DescricaoMensalidade_Plano");

                jComboBoxPlano.addItem(nomePlano);
                precoArray.add(precoPlano);
                duracaoArray.add(duracao);

                //contadorComboBox += 1;

            }
            //JOptionPane.showMessageDialog(null, "opções de planos: " + contadorComboBox);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro: " + e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtMatriculaAluno = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnConfirmarPagamento = new javax.swing.JButton();
        btnCancelarPagamento = new javax.swing.JButton();
        jComboBoxPlano = new javax.swing.JComboBox<>();
        jComboBoxFormaPagamento = new javax.swing.JComboBox<>();
        txtDtPagamento = new javax.swing.JFormattedTextField();
        txtPreco = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtDtFim = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtDtInicio = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jComboBoxSituacao = new javax.swing.JComboBox<>();
        txtNomeAluno = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro de Pagamento");

        jLabel1.setText("Nome do Aluno:");

        jLabel2.setText("Preço:");

        jLabel3.setText("Matrícula do Aluno:");

        txtMatriculaAluno.setEditable(false);

        jLabel4.setText("Plano:");

        jLabel5.setText("Data Pagamento:");

        jLabel10.setText("Forma de Pagamento: ");

        btnConfirmarPagamento.setText("Confirmar");
        btnConfirmarPagamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarPagamentoActionPerformed(evt);
            }
        });

        btnCancelarPagamento.setText("Cancelar");
        btnCancelarPagamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarPagamentoActionPerformed(evt);
            }
        });

        jComboBoxPlano.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));
        jComboBoxPlano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxPlanoActionPerformed(evt);
            }
        });

        jComboBoxFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dinheiro", "Cartão", "Pix" }));

        txtDtPagamento.setEditable(false);
        txtDtPagamento.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter()));

        txtPreco.setEditable(false);

        jLabel14.setText("Data Fim:");

        txtDtFim.setEditable(false);

        jLabel13.setText("Data Início:");

        txtDtInicio.setEditable(false);

        jLabel16.setText("Situação:");

        jComboBoxSituacao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ativa", "Pendente", "Encerrada" }));
        jComboBoxSituacao.setSelectedIndex(1);
        jComboBoxSituacao.setEnabled(false);

        txtNomeAluno.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jComboBoxSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtDtPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btnConfirmarPagamento)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel13)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtDtInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jLabel14)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtDtFim)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(0, 0, Short.MAX_VALUE)
                                    .addComponent(btnCancelarPagamento))))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(jLabel1))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtMatriculaAluno, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                                .addComponent(txtNomeAluno)))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jComboBoxPlano, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel10)
                                    .addGap(5, 5, 5)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jComboBoxFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel2)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(0, 22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtMatriculaAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNomeAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBoxPlano, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(txtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jComboBoxFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtDtPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtDtInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(txtDtFim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jComboBoxSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirmarPagamento)
                    .addComponent(btnCancelarPagamento))
                .addGap(32, 32, 32))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxPlanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxPlanoActionPerformed
        // Formatter para o formato "dd/MM/yyyy"
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        // Obter a data do txtDtPagamento e converter para LocalDate
        LocalDate dataPagamento = LocalDate.parse(txtDtPagamento.getText(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        // Definir a data de início como a data de pagamento (convertida para o novo formato)
        txtDtInicio.setText(dataPagamento.format(formatter));

        // Verificar qual plano foi escolhido
        int planoEscolhido = jComboBoxPlano.getSelectedIndex();

        // Caso nenhum plano seja selecionado, limpar os campos
        if (planoEscolhido == 0) {
            txtPreco.setText("");
            txtDtInicio.setText("");
            txtDtFim.setText("");
            return;
        }

        // Obter o preço e a duração do plano selecionado
        double preco = precoArray.get(planoEscolhido - 1);  // Preço do plano
        int duracao = duracaoArray.get(planoEscolhido - 1);  // Duração do plano em meses (ou anos)

        // Atualizar o campo de preço
        txtPreco.setText(String.valueOf(preco));

        // Calcular a data de término com base na duração (adicionando meses ou anos)
        LocalDate dataFim = dataPagamento.plusMonths(duracao);  // Adiciona a duração (em meses ou anos) à data de pagamento

        // Definir a data fim no formato "dd/MM/yyyy"
        txtDtFim.setText(dataFim.format(formatter));
    }//GEN-LAST:event_jComboBoxPlanoActionPerformed

    private void btnCancelarPagamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarPagamentoActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnCancelarPagamentoActionPerformed

    private void btnConfirmarPagamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarPagamentoActionPerformed
        int matriculaAluno = Integer.parseInt(txtMatriculaAluno.getText());
        String nomeAluno = txtNomeAluno.getText();

        // Pegar o nome do plano selecionado no JComboBox
        String plano = (String) jComboBoxPlano.getSelectedItem();  // Aqui pegamos o nome diretamente do JComboBox
        double preco = 0;

        // Verificar se algum plano foi selecionado
        int planoEscolhido = jComboBoxPlano.getSelectedIndex();

        if (planoEscolhido == 0) {
            JOptionPane.showMessageDialog(null, "Selecione um plano!");
            return;
        }

        // Obter o preço do plano da lista precoArray
        preco = precoArray.get(planoEscolhido - 1);  // O índice do plano no ComboBox começa em 1, mas em precoArray começa em 0

        // forma de pagamento
        String formaPagamento = "";
        int formaEscolhida = jComboBoxFormaPagamento.getSelectedIndex();

        if (formaEscolhida == 0) {
            formaPagamento = "Dinheiro";
        } else if (formaEscolhida == 1) {
            formaPagamento = "Cartão";
        } else {
            formaPagamento = "Pix";
        }

        // Obter a data de pagamento
        Date dtPagamento = null;
        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            formato.setLenient(false);
            dtPagamento = formato.parse(txtDtPagamento.getText());
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
        }

        // Obter a data de início
        Date dtInicio = null;
        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            formato.setLenient(false);
            dtInicio = formato.parse(txtDtInicio.getText());
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
        }

        // Obter a data de fim
        Date dtFim = null;
        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            formato.setLenient(false);
            dtFim = formato.parse(txtDtFim.getText());
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
        }

        String situacao = "Ativa";

        // Criar o objeto Pagamento com os dados coletados
        pagamento = new Pagamento(codigoAtual, matriculaAluno, nomeAluno, plano, preco, formaPagamento, dtPagamento, dtInicio, dtFim, situacao);

        registrarPagamento();

        dispose();
        gerenciamentoPagamento.carregarDadosPagamentos();
        gerenciamentoAlunos.carregarDadosAlunos();
    }//GEN-LAST:event_btnConfirmarPagamentoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelarPagamento;
    private javax.swing.JButton btnConfirmarPagamento;
    private javax.swing.JComboBox<String> jComboBoxFormaPagamento;
    private javax.swing.JComboBox<String> jComboBoxPlano;
    private javax.swing.JComboBox<String> jComboBoxSituacao;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField txtDtFim;
    private javax.swing.JTextField txtDtInicio;
    private javax.swing.JFormattedTextField txtDtPagamento;
    private javax.swing.JTextField txtMatriculaAluno;
    private javax.swing.JTextField txtNomeAluno;
    private javax.swing.JTextField txtPreco;
    // End of variables declaration//GEN-END:variables
}
