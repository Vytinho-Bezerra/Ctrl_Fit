package ctrlfit.telas;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import ctrlfit.entity.Exercicio;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GerenciamentoTreinos extends javax.swing.JFrame {

    private boolean pesquisarAluno = false;
    Exercicio exercicio;

    public GerenciamentoTreinos() {
        initComponents();
        jTableTreinos.setDefaultEditor(Object.class, null);//Deixa a jTable não editavel
        carregarDadosTreinos();
    }

    public void carregarDadosTreinos() {
        try {
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "";
            PreparedStatement st;

            if (pesquisarAluno) {
                int matriculaAluno = Integer.parseInt(txtPesquisarAluno.getText());
                int opcao = jComboBoxPesquisarTreino.getSelectedIndex();

                if (opcao == 1) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Aluno_Matricula_Aluno = ? AND Divisao_Treino = 'A'";
                } else if (opcao == 2) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Aluno_Matricula_Aluno = ? AND Divisao_Treino = 'B'";
                } else if (opcao == 3) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Aluno_Matricula_Aluno = ? AND Divisao_Treino = 'C'";
                } else if (opcao == 4) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Aluno_Matricula_Aluno = ? AND Divisao_Treino = 'D'";
                } else if (opcao == 5) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Aluno_Matricula_Aluno = ? AND Divisao_Treino = 'E'";
                } else {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Aluno_Matricula_Aluno = ? ORDER BY Divisao_Treino";
                }

                st = conexao.prepareStatement(sql);
                st.setInt(1, matriculaAluno);// Define o valor para o parâmetro

            } else {
                int opcao = jComboBoxPesquisarTreino.getSelectedIndex();

                if (opcao == 1) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Divisao_Treino = 'A'";
                } else if (opcao == 2) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Divisao_Treino = 'B'";
                } else if (opcao == 3) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Divisao_Treino = 'C'";
                } else if (opcao == 4) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Divisao_Treino = 'D'";
                } else if (opcao == 5) {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Divisao_Treino = 'E'";
                } else {
                    sql = "SELECT Codigo_Treino, Aluno_Matricula_Aluno, Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino";
                }

                st = conexao.prepareStatement(sql);

            }

            ResultSet rs = st.executeQuery();

            // Obter o modelo da tabela e limpar dados anteriores
            DefaultTableModel model = (DefaultTableModel) jTableTreinos.getModel();
            model.setRowCount(0);

            // Iterar pelos resultados e adicionar à tabela
            while (rs.next()) {
                int codigoTreino = rs.getInt("Codigo_Treino");
                int matriculaAluno = rs.getInt("Aluno_Matricula_Aluno");
                char divisaoTreino = rs.getString("Divisao_Treino").charAt(0);
                String nomeTreino = rs.getString("Nome_Treino");
                int series = rs.getInt("QuantSeries_Treino");
                int repeticoes = rs.getInt("QuantRepeticoes_Treino");
                String observacoes = rs.getString("Observacoes_Treino");
                model.addRow(new Object[]{codigoTreino, matriculaAluno, divisaoTreino, nomeTreino, series, repeticoes, observacoes});
            }

        } catch (SQLException e) {
            System.out.println("Erro ao carregar dados: " + e.getMessage());
        }
    }

    public void excluir() {
        try {
            //estabelecer a conexão com o banco de dados
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "DELETE FROM mensalidade_plano WHERE CodigoMensalidade_Plano = ?";
            PreparedStatement st = conexao.prepareStatement(sql);

            // Define o valor para o parâmetro (codigo_contato)
            st.setInt(1, exercicio.getCodigo());

            // Executar o DELETE
            st.executeUpdate();

            JOptionPane.showMessageDialog(this, "Exclusão realizada com sucesso!");
            carregarDadosTreinos();
        } catch (SQLException e) {
            System.out.println("Erro ao excluir exercício: " + e.getMessage());
        }
    }

    public void emitirTreino() {

        Document document = new Document();

        try {
            PdfWriter.getInstance(document, new FileOutputStream("FichaDeTreino.pdf"));
            document.open();

            // Criando a fonte em negrito
            Font fontTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);

            // Adicionando o título
            Paragraph titulo = new Paragraph("FICHA DE TREINO", fontTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER); // Centraliza o título
            document.add(titulo);

            // Adicionando a matrícula e a data
            document.add(new Paragraph("Matrícula do aluno(a): " + txtPesquisarAluno.getText()));
            Date data = new Date();
            DateFormat formatador = DateFormat.getDateInstance(DateFormat.FULL);
            document.add(new Paragraph("Emissão: " + formatador.format(data)));
            document.add(new Paragraph(" "));// Pular linha

            // Conectar ao banco de dados
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();
            int matriculaAluno = Integer.parseInt(txtPesquisarAluno.getText());

            // Consulta para obter os dados do treino
            String sql = "SELECT Divisao_Treino, Nome_Treino, QuantSeries_Treino, QuantRepeticoes_Treino, Observacoes_Treino FROM treino WHERE Aluno_Matricula_Aluno = ? ORDER BY Divisao_Treino";
            PreparedStatement st = conexao.prepareStatement(sql);
            st.setInt(1, matriculaAluno);
            ResultSet rs = st.executeQuery();

            // Variáveis para controlar o treino atual
            String treinoAtual = "";

            // Criar tabela fora do laço
            PdfPTable tabela = null;

            // Adiciona as linhas da tabela
            while (rs.next()) {
                String divisaoTreino = rs.getString("Divisao_Treino");
                String nomeTreino = rs.getString("Nome_Treino");
                String quantSeries = rs.getString("QuantSeries_Treino");
                String quantRepeticoes = rs.getString("QuantRepeticoes_Treino");
                String observacoes = rs.getString("Observacoes_Treino");

                // Se a divisão do treino mudar, adicione um novo título de treino e uma nova tabela
                if (!treinoAtual.equals(divisaoTreino)) {
                    if (!treinoAtual.isEmpty()) {
                        document.add(tabela); // Adiciona a tabela anterior ao documento
                        document.add(new Paragraph(" ")); // Espaço entre os treinos
                    }

                    // Atualiza o treino atual
                    treinoAtual = divisaoTreino;

                    // Adiciona o título do treino
                    Paragraph tituloTreino = new Paragraph("Treino: " + divisaoTreino, fontTitulo);
                    tituloTreino.setSpacingBefore(10); // Espaço antes do título do treino
                    tituloTreino.setSpacingAfter(5);  // Espaço após o título do treino
                    document.add(tituloTreino);

                    // Cria uma nova tabela para o novo treino
                    tabela = new PdfPTable(4); // Número de colunas ajustado para 4
                    tabela.setWidthPercentage(100);

                    // Adiciona os títulos das colunas
                    tabela.addCell("Exercício");
                    tabela.addCell("Séries");
                    tabela.addCell("Repetições");
                    tabela.addCell("Observações");
                }

                // Adiciona os dados do exercício na tabela
                tabela.addCell(nomeTreino);
                tabela.addCell(quantSeries);
                tabela.addCell(quantRepeticoes);
                tabela.addCell(observacoes);
            }

            // Adiciona a última tabela ao documento
            if (tabela != null) {
                document.add(tabela);
            }

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            document.close();
        }

        // Abrir o pdf automaticamente no leitor padrão do sistema
        try {
            Desktop.getDesktop().open(new File("FichaDeTreino.pdf"));
        } catch (Exception e2) {
            System.out.println("Erro: " + e2.getMessage());
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTableTreinos = new javax.swing.JTable();
        btnCadastrarTreino = new javax.swing.JButton();
        btnExibirTreino = new javax.swing.JButton();
        btnExcluirTreino = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtPesquisarAluno = new javax.swing.JTextField();
        btnPesquisarAluno = new javax.swing.JButton();
        btnEmitirTreino = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnAtualizar = new javax.swing.JButton();
        jComboBoxPesquisarTreino = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gerenciamento de Treinos");

        jTableTreinos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Matrícula", "Treino", "Exercício", "Séries", "Repetições", "Observações"
            }
        ));
        jScrollPane2.setViewportView(jTableTreinos);
        if (jTableTreinos.getColumnModel().getColumnCount() > 0) {
            jTableTreinos.getColumnModel().getColumn(0).setMaxWidth(70);
            jTableTreinos.getColumnModel().getColumn(1).setMaxWidth(70);
            jTableTreinos.getColumnModel().getColumn(2).setMaxWidth(70);
            jTableTreinos.getColumnModel().getColumn(4).setMaxWidth(70);
            jTableTreinos.getColumnModel().getColumn(5).setMaxWidth(70);
        }

        btnCadastrarTreino.setText("Cadastrar");
        btnCadastrarTreino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarTreinoActionPerformed(evt);
            }
        });

        btnExibirTreino.setText("Exibir");
        btnExibirTreino.setToolTipText("Exibir ou Alterar dados");
        btnExibirTreino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExibirTreinoActionPerformed(evt);
            }
        });

        btnExcluirTreino.setText("Excluir");
        btnExcluirTreino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirTreinoActionPerformed(evt);
            }
        });

        jLabel1.setText("Pesquisar Matrícula:");

        btnPesquisarAluno.setText("Pesquisar");
        btnPesquisarAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarAlunoActionPerformed(evt);
            }
        });

        btnEmitirTreino.setText("Emitir Treino");
        btnEmitirTreino.setEnabled(false);
        btnEmitirTreino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEmitirTreinoActionPerformed(evt);
            }
        });

        jLabel2.setText("Pesquisar Treino:");

        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        jComboBoxPesquisarTreino.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos", "A", "B", "C", "D", "E" }));
        jComboBoxPesquisarTreino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxPesquisarTreinoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 789, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnEmitirTreino)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtPesquisarAluno, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnPesquisarAluno)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnCadastrarTreino)
                                .addGap(18, 18, 18)
                                .addComponent(btnExibirTreino)
                                .addGap(18, 18, 18)
                                .addComponent(btnExcluirTreino))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBoxPesquisarTreino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAtualizar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBoxPesquisarTreino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAtualizar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCadastrarTreino)
                    .addComponent(btnExibirTreino)
                    .addComponent(btnExcluirTreino)
                    .addComponent(jLabel1)
                    .addComponent(txtPesquisarAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPesquisarAluno))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEmitirTreino)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarTreinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarTreinoActionPerformed
        CadastroExercicio cadastroExers = new CadastroExercicio(this);
        cadastroExers.setVisible(true);
    }//GEN-LAST:event_btnCadastrarTreinoActionPerformed

    private void btnExibirTreinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExibirTreinoActionPerformed
        //armazena o indice da linha na variavel linhaSelecionada, a primeira linha é 0, -1 para nenhuma linha selecionada
        int linhaSelecionada = jTableTreinos.getSelectedRow();

        if (linhaSelecionada != -1) {
            //obetr os valores da linha selecionada
            int codigo = (int) jTableTreinos.getValueAt(linhaSelecionada, 0);

            int codigoTreino = 0;
            int matriculaAluno = 0;
            char divisaoTreino = ' ';
            String nomeTreino = "";
            int series = 0;
            int repeticoes = 0;
            String observacoes = "";

            try {
                Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();
                String sql = "SELECT * FROM treino WHERE Codigo_Treino = ?";
                PreparedStatement stmt = conexao.prepareStatement(sql);
                stmt.setInt(1, codigo);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    codigoTreino = rs.getInt("Codigo_Treino");
                    matriculaAluno = rs.getInt("Aluno_Matricula_Aluno");
                    divisaoTreino = rs.getString("Divisao_Treino").charAt(0);
                    nomeTreino = rs.getString("Nome_Treino");
                    series = rs.getInt("QuantSeries_Treino");
                    repeticoes = rs.getInt("QuantRepeticoes_Treino");
                    observacoes = rs.getString("Observacoes_Treino");
                }

            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            }

            CadastroExercicio cadastroExers = new CadastroExercicio(this);
            cadastroExers.setVisible(true);

            //chama o metodo trazerDados da classse CadastroExercicio passando como parametro os valores da linha selecionada
            cadastroExers.trazerDados(codigoTreino, matriculaAluno, divisaoTreino, nomeTreino, series, repeticoes, observacoes);

        } else {
            JOptionPane.showMessageDialog(null, "Selecione uma linha para exibir!");
        }
    }//GEN-LAST:event_btnExibirTreinoActionPerformed

    private void btnExcluirTreinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirTreinoActionPerformed
        //armazena o indice da linha na variavel linhaSelecionada, a primeira linha é 0, -1 para nenhuma linha selecionada
        int linhaSelecionada = jTableTreinos.getSelectedRow();

        if (linhaSelecionada != -1) {
            // Obter o codigo da linha selecionada
            int codigo = (int) jTableTreinos.getValueAt(linhaSelecionada, 0);

            exercicio = new Exercicio();
            exercicio.setCodigo(codigo);
            // Tela para confirmar exclusão
            //int resposta = JOptionPane.showConfirmDialog(null, "Você deseja realmente excluir esse exercício?");
            Object[] opcoes = {"Sim", "Não"};
            int resposta = JOptionPane.showOptionDialog(
                    this,
                    "Você deseja realmente excluir esse exercício?",
                    "Confirmação de Exclusão",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null, // Ícone padrão
                    opcoes, // Opções de botões personalizadas
                    opcoes[0] // Opção padrão selecionada
            );

            if (resposta == JOptionPane.YES_OPTION) {
                excluir();
            }

        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma linha para excluir!");
        }
    }//GEN-LAST:event_btnExcluirTreinoActionPerformed

    private void btnPesquisarAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarAlunoActionPerformed
        if (txtPesquisarAluno.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Digite a matrícula do aluno(a) para pesquisar.");
        } else {
            pesquisarAluno = true;
            carregarDadosTreinos();
            btnEmitirTreino.setEnabled(true);
            jComboBoxPesquisarTreino.setSelectedIndex(0);
        }


    }//GEN-LAST:event_btnPesquisarAlunoActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        pesquisarAluno = false;
        carregarDadosTreinos();
        txtPesquisarAluno.setText("");
        btnEmitirTreino.setEnabled(false);
        jComboBoxPesquisarTreino.setSelectedIndex(0);
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnEmitirTreinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEmitirTreinoActionPerformed
        emitirTreino();
    }//GEN-LAST:event_btnEmitirTreinoActionPerformed

    private void jComboBoxPesquisarTreinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxPesquisarTreinoActionPerformed
        carregarDadosTreinos();
    }//GEN-LAST:event_jComboBoxPesquisarTreinoActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnCadastrarTreino;
    private javax.swing.JButton btnEmitirTreino;
    private javax.swing.JButton btnExcluirTreino;
    private javax.swing.JButton btnExibirTreino;
    private javax.swing.JButton btnPesquisarAluno;
    private javax.swing.JComboBox<String> jComboBoxPesquisarTreino;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableTreinos;
    private javax.swing.JTextField txtPesquisarAluno;
    // End of variables declaration//GEN-END:variables
}
