package ctrlfit.conexao;

import ctrlfit.entity.Usuario;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;

public class UsuarioDAO {

    Connection conn;

    public ResultSet autenticacaoUsuario(Usuario objusuariodto) {
        conn = ConexaoDAO.conectarBD();

        try {
            String sql = "select * from usuario_sistema where Nome_Usuario = ? and Senha_Usuario = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, objusuariodto.getNome_usuario());
            pstm.setString(2, objusuariodto.getSenha_usuario());

            ResultSet rs = pstm.executeQuery();
            return rs;

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "UsuarioDAO:" + erro);
            return null;
        }
    }
}
